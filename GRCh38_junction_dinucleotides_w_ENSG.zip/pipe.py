import re
import warnings
import os

import pandas as pd


PATH = os.path.dirname(__file__)


GENE_LENGTH = pd.read_csv(PATH+'/ensembl_transcript_lengths_w_ENSG.tsv', sep = '\t', index_col = 0).drop('Principal Transcript', axis = 1).to_dict()['Length']
FNAMES = {'codon':'/GRCh38_codons_w_ENSG.tsv',
          'bicod':'/GRCh38_bicodons_w_ENSG.tsv',
          'dinuc':'/GRCh38_dinucleotides_w_ENSG.tsv',
          'junc_dinuc':'/GRCh38_junction_dinucleotides_w_ENSG.tsv'
         }

NORMALIZE = { key:1000000 if key == 'bicod' else 1000
             for key in FNAMES.keys()}

COCOP = {}
for _name in FNAMES:
    COCOP[_name] = pd.read_csv(PATH + FNAMES[_name], sep = '\t', index_col = 0)
    COCOP[_name] = COCOP[_name][~COCOP[_name]['Transcript'].str.contains('PAR_Y')].drop('Transcript', axis = 1)
    COCOP[_name].index = [x[:x.rfind('.')] for x in COCOP[_name].index.values]
    COCOP[_name] = COCOP[_name].transpose()


#metadata used to identify tissue type of TCGA RNA seq read count files
#Supplemental Table 1: see <publication link>
#categories.tsv: 
    #Information associated with each file name
    #Case ID, Diagnosis, Tissue or Organ of Origin...
    #Information collected from gdc_sample_sheet.tsv and clinical.cart.tar.gz
    #downloaded from https://portal.gdc.cancer.gov/repository on 07/30/2020
    #along with 16175 RNAseq read count files
    
FNAMES['sup1'] = '/Supplemental Table 1.xlsx'
FNAMES['meta'] = '/categories.tsv'

_cancer_temp = pd.read_excel(PATH + FNAMES['sup1'], sheet_name = 'Cancer Full List')
_normal_temp = pd.read_excel(PATH + FNAMES['sup1'], sheet_name = 'Normal Tissue Full List')

#key:value = cancer_type:list of matching (diagnosis,tissue_of_origin) tuples 
DIAG_ORIG_DIC = {}
for ind,row in _cancer_temp.set_index('Cancer Type').iterrows():
    if ind not in DIAG_ORIG_DIC:
        DIAG_ORIG_DIC[ind] = []
    DIAG_ORIG_DIC[ind].append(tuple(row))

#key:value = normal_type:list of matching tissue_of_origin strings
ORIG_DIC = {}
for ind,row in _normal_temp.set_index('Normal Tissue Type').iterrows():
    if ind not in ORIG_DIC:
        ORIG_DIC[ind] = []
    ORIG_DIC[ind].append(row.values[0])    
    
META_DF = pd.read_csv(PATH + FNAMES['meta'], sep = '\t', index_col = 'File Name')

       
def read_to_tpm(read_count_df, **kwargs):
    '''
    Summary
        computes Transcript per million (TPM) for each gene based on given RNA-seq read counts
            assumes all gene names are unique regardless of version
            (ie ENSG01.2 is the same as ENSG01.7; assumes both will not appear in same RNA-seq read count file)
        returns results as pandas.DataFrame with each row being a gene name followed by its TPM
        issues RuntimeWarning if sum of all TPM for a file is >1000000.001 or <999999.999

    Input Parameters:  
        read_count_df
            pandas.DataFrame containing RNA-seq read counts
            index values are gene names (ie "ENSG000073.7")
            should only include 1 column
                if df contains multiple columns, only left most will be used for calculation

    Keyword Arguments:
        gene_lengths
            dictionary with gene name: length mappings
            only genes present in gene_lengths dictionary will be used to compute tpm
            if not provided, default values read from <> file

        exclude
            list of strings representing gene names
            default excludes all mitochondrial genes
            genes in "excluded" will not be used in tpm calculation, even if present in "gene_lengths"
            version is ignored (ie "ENSG01.2" is treated the same as "ENSG01.7" and "ENSG01")

        get_sum
            bool 
            if True, return value will be a tuple which will include tpm_df and the sum of all tpm values in it

    Returns:
        tpm_df
            pandas.DataFrame with single column ("tpm") and gene names as index.
            gene names here will not include version numbers (ie "ENSG01.1" is not possible, but "ENSG01" is)


    '''
    try:
        gene_lengths = kwargs['gene_lengths']
        assert type(gene_lengths) == dict
    except:
        gene_lengths = GENE_LENGTH
        
    try:
        exclude = kwargs['excluded']
        assert(all([type(x)==str for x in exclude]))
    except:
        exclude =  ['ENSG00000198888', 'ENSG00000198763', 'ENSG00000198804', 'ENSG00000198712', 'ENSG00000228253', 'ENSG00000198899', 'ENSG00000198938', 'ENSG00000198840', 'ENSG00000212907', 'ENSG00000198886', 'ENSG00000198786', 'ENSG00000198695', 'ENSG00000198727']

        
    try:
        get_sum = kwargs['get_sum']
        assert(get_sum == True)
    except:
        get_sum = False
        
    
    gene_length_df = pd.DataFrame({'length':gene_lengths})
    gene_length_df.index = [x[:x.rfind('.')] for x in gene_length_df.index.values]
    
    col = read_count_df.columns.values[0]
    gene_counts_df = read_count_df.loc[:, [col]]
    gene_counts_df.index = [x[:x.rfind('.')] for x in gene_counts_df.index.values]
    
    #olap is list of genes for which gene_length and gene_count information is available
    #only these genes will be used for tpm calculation
    olap = sorted(set(gene_counts_df.index.values)&set(gene_length_df.index.values),
                  key = lambda x: int(re.findall('[A-Za-z]*([0-9]+).*[0-9]*',x)[0]))
    olap = [gene for gene in olap if gene not in exclude]
    
    try:
        assert(len(olap)>=10000)
    except AssertionError:
        warnings.warn("\n\n{x} genes used for tpm calculation".format(x=len(olap)), RuntimeWarning)
    
    gene_counts_df = gene_counts_df.loc[olap, [col]].join(gene_length_df.loc[olap, ['length']])
    
    tpm_df = pd.DataFrame(gene_counts_df[col]/gene_counts_df['length'], columns = [col])
    scaling_factor = sum(tpm_df[col])/1000000
    
    tpm_df = tpm_df/scaling_factor
        
    #verify tpm values sum up to 1000000
    try:
        assert(abs(sum(tpm_df[col])-1000000) < 0.001)
    except AssertionError:
        warnings.warn("\n\nSum of all tpms is {x}".format(x=round(sum(tpm_df[col]),3)), RuntimeWarning)
    finally:
        if get_sum:
            return (tpm_df, sum(tpm_df[col]))
        else:
            return tpm_df   

def tpm_to_cocop(tpm_df,name, n = True):
    '''
    Summary
        Computes transcriptome weighted codon, codon_pair, dinucleotide or junction_dinucleotide usage
        returns results as pandas.DataFrame with each row being a codon/codon_pair/dinucleotide/junction_dinucleotide
        computation only uses genes present in both tpm_df and COCOP[name]
            if more than 5% of COCOP[name] genes are ignored, issues RuntimeWarning

    Input Parameters:  
        tpm_df
            pandas.DataFrame containing tpm values
            index values are gene names (ie "ENSG000073.7")
            column names identify sample (ie file_id, case_id, etc.)
        
        name
            string indicating which value to compute
            raises ValueError if name is not a key in COCOP dict
            
        norm (optional, default True) bool indicating whether returned values should be normalized
            if true, each column in returned df will have a sum equal to NORMALIZE[name]
            (10^6 for bicod, 10^3 for codon, dinuc and junc_dinuc)
        

    Keyword Arguments:
        NONE

    Returns:
        tpm_df
            pandas.DataFrame with single column ("tpm") and gene names as index.
            index values will not include version numbers (ie "ENSG01.1" is not possible, but "ENSG01" is)
    '''
    
    try:
        assert name in COCOP.keys()
    except:
        raise ValueError("name value must be in ['{x}']".format(x="', '".join(COCOP.keys())))
        
    try:
        assert(n==True)
        norm = True
    except:
        norm = False
        
    olap = list(set([re.findall('([A-Za-z]+[0-9]+).*[0-9]*',x)[0] for x in tpm_df.index.values])
                &set(COCOP[name].columns.values))
    
    res = COCOP[name].loc[:, olap].dot(tpm_df.loc[olap, :])
    if norm:
        res = res.div(res.sum(axis=0), axis=1)*NORMALIZE[name]
    
    try:
        assert len(olap)>=0.95*COCOP[name].shape[1]
    except:
        warnings.warn("\n\n{x} usage calculated using {y}/{z} genes".format(x=name, y=len(olap)), RuntimeWarning)
    finally:
        return res

def file_to_read_count(folder, fname, sep = '\t'):
    #reads htseq.counts file into pandas.DataFrame
    #Only works if file has two columns: 1. Gene Name; 2. read_count
    #    ie htseq.counts files from NCI GDC repository
    
    df =  pd.read_csv('{x}/{y}'.format(x=folder, y=fname), sep = sep, index_col = 0, header = None)
    df = df.drop([ind for ind in df.index.values if ind[0] in ['_', '-'] or ind[-1] not in '1234567890'])
    df.index = df.index.rename('Gene')
    df.columns = [fname]
    return df
    
    
def fnames_to_table(folder, fname_list, table_type):
    '''
    Summary
        creates pandas.DataFrame of specified type containing data from all specified files

    Input Parameters:  
        folder
            string representing location of read count data files
        
        fname_list
            list of strings, each representing a file name for inclusion in the final table
            
        table_type
            string indicating the type of table to be generated (case-sensitive). 
                must be in COCOP.keys() or 'read_count' or 'tpm'
                
    Keyword Arguments:
        NONE

    Returns:
        pandas.DataFrame
            table values depend on the specified table_type 
            see read_count_to_tpm, tpm_to_cocop for more information
    '''
    
    supported = list(COCOP.keys()) + ['read count', 'tpm']
    
    try:
        assert(table_type in supported)
    except AssertionError:
        raise ValueError("table_type value must be in ['{x}']".format(x="', '".join(supported)))
    
    read_table =  pd.concat([file_to_read_count(folder,f).transpose() for f in fname_list]).transpose()
    if table_type == 'read count':
        return read_table
    
    tpm_table = pd.concat([read_to_tpm(read_table.loc[:,[col]].copy()).transpose() for col in read_table]).transpose()
    if table_type == 'tpm':
        return tpm_table
    
    return tpm_to_cocop(tpm_table, table_type)

def fnames_to_median(folder, fname_list, table_type):
    table = fnames_to_table(folder, fname_list, table_type)
    return pd.DataFrame({'median':table.median(axis=1)})

def fnames_to_table_with_median(folder, fname_list, table_type):
    return fnames_to_median(folder, fname_list, table_type).join(fnames_to_table(folder, fname_list, table_type))

def cancer_type_to_fnames(meta_df, diag_orig):
    '''
    Summary
        Parses metadata and clinical information about each sample and returns
        all tumor files of the given cancer type.

    Input Parameters:  
        meta_df
            pandas.DataFrame with RNA-seq read count file names as its index
            must include the following columns:
                "Diagnosis"
                "Tissue or Organ of Origin"
                "Sample Type"
                "Prior Treatment"
        
        diag_orig
            list of tuples representing (diagnosis,tissue or organ of origin)
                the (Diagnosis, Tissue or Organ of Origin) of all returned file names match a value in diag_orig

    Keyword Arguments:
        NONE

    Returns:
        list of meta_df index values matching selection criteria. 
        Index values should be filenames so returned values will be a list filenames matching selection criteria.

    '''
                     #file names corresponding to primary tumors
                     #with no prior treatment
                     #whose diagnosis,tissue of origin match diag_orig        
    return list(meta_df[
        (meta_df['Sample Type']=='Primary Tumor')    
       &(meta_df['Prior Treatment']=='No')
       &(meta_df[["Diagnosis","Tissue or Organ of Origin"]].apply(tuple, 1).isin(diag_orig))
    ].index.values)
       
def normal_type_to_fnames(meta_df, orig):
    '''
    Summary
        Parses metadata and clinical information about each sample and returns
        all normal tissue files of the given tissue type.

    Input Parameters:  
       
        meta_df
            pandas.DataFrame with RNA-seq read count file names as its index
            must include the following columns:
                "Tissue or Organ of Origin"
                "Sample Type"
                "Prior Treatment"
        
        orig
            list of "Tissue or Organ of Origin" values which match input normal_type value

    Keyword Arguments:
        NONE

    Returns:
        list of meta_df index values matching selection criteria. 
        Index values should be filenames so returned values will be a list filenames matching selection criteria.

    '''
                     #file names corresponding to normal tissue samples
                     #with no prior treatment
                     #whose tissue of origin is included in orig        
    return list(meta_df[
        (meta_df['Sample Type']=='Solid Tissue Normal')    
       &(meta_df['Prior Treatment']=='No')
       &(meta_df["Tissue or Organ of Origin"].isin(orig))
    ].index.values)

def get_paired(diag_orig, orig, meta_df):
    '''
    Summary
        Identifies paired samples (1 tumor + 1 normal tissue from same patient)
        returns results as dataframe

    Input Parameters:  
       
        diag_orig
            list of tuples representing (diagnosis,tissue or organ of origin)
                the (Diagnosis, Tissue or Organ of Origin) of all returned file names match a value in diag_orig
        
        orig
            list of "Tissue or Organ of Origin" values which match input normal_type value
            
        meta_df
            pandas.DataFrame with RNA-seq read count file names as its index
            must include the following columns:
                "Diagnosis" 
                "Tissue or Organ of Origin"
                "Sample Type"
                "Prior Treatment"
                "Case ID"
        

    Keyword Arguments:
        NONE

    Returns:
        pandas.DataFrame
            index values are filenames
            two columns included from metadata: Case ID and Sample Type
            only cases with 1 normal tissue sample and 1 tumor tissue sample are included

    '''
    cancer_files = cancer_type_to_fnames(meta_df, diag_orig)
    normal_files = normal_type_to_fnames(meta_df, orig)
    
    normal_meta = meta_df.loc[normal_files, :]
    #cases with exactly 1 normal sample
    normal_cases = set(normal_meta[~normal_meta.duplicated('Case ID', False)]['Case ID'])

    cancer_meta = meta_df.loc[cancer_files, :]
    #cases with exactly 1 tumor sample
    cancer_cases = set(cancer_meta[~cancer_meta.duplicated('Case ID', False)]['Case ID'])

    paired_df = meta_df[(meta_df['Case ID'].isin(normal_cases&cancer_cases))
           &(meta_df['Sample Type'].isin(['Primary Tumor', 'Solid Tissue Normal']))
           ].loc[:,['Case ID', 'Sample Type']].sort_values(by = ['Case ID', 'Sample Type'])
    
    return paired_df

def get_rev_paired(diag_orig, orig, meta_df):
    '''
    same as get_paired, but index column swapped with data columns (index = (Case ID, Sample Type), column = File Name)
    
    Returns
        pandas.DataFrame
            index values are (Case ID, Sample Type) tuples
            one column included from meta_df: File Name
            only cases with 1 normal tissue sample and 1 tumor tissue sample are included
    
    '''
    return get_paired(diag_orig, orig, meta_df).reset_index().set_index(['Case ID', 'Sample Type'])